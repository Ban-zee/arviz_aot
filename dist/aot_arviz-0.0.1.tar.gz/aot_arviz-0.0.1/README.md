## AOT compiler for arviz stats


__name__="aot_arviz"
__version__ = "0.0.1"



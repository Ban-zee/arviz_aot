__name__="aot_arviz"
__version__ = "0.0.1"

from arviz_aot.numba_compilations import *
